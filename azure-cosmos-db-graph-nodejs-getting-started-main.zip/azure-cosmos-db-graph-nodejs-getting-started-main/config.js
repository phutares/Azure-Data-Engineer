var config = {}

config.endpoint = "wss://DATABASE_ACCOUNT_NAME.gremlin.cosmosdb.azure.com:443/gremlin";
config.primaryKey = "PRIMARYKEY";
config.database = "GRAPHDATABASE"
config.collection = "GRAPHCOLLECTION"

module.exports = config;
